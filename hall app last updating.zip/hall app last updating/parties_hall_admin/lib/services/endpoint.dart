
class EndPoint{

  static const String adminLogin = "account/adminLogin.php";
  static const String addHall = "hall/addHall.php";
}