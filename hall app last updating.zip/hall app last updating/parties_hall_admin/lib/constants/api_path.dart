
class ApiPath {
  static const String baseUrl = 'https://partieshall.000webhostapp.com/PartiesHallApp/api/';
  static const String baseUrlImage = 'https://partieshall.000webhostapp.com/PartiesHallApp/images/';
}