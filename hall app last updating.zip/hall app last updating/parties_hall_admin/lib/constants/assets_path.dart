
class AssetsPath{
static const String icon_error = 'assets/images/icon_error.png';
static const String icon_info = 'assets/images/icon_info.png';
static const String icon_success = 'assets/images/icon_success.png';
static const String icon_warning = 'assets/images/icon_warning.png';
static const String icon_hall = 'assets/images/icon_hall.jpg';
static const String add_image = 'assets/images/add_image.png';
}