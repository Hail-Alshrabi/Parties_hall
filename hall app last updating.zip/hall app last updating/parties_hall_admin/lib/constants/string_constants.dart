const String txt_appName = 'تطبيق الأدمن';
const String txt_notInternet = 'لايوجد إنترنت';

const String api_key_map ='AIzaSyCmWB8NkYeWkcN-e8ErJTIlzG13geVuyjg';