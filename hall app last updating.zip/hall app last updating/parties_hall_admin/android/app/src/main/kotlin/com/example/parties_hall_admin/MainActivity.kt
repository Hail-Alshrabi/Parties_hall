package com.example.parties_hall_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
