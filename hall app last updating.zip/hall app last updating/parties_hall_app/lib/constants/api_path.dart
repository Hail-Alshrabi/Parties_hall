
class ApiPath {
  static const String baseUrl = 'http://192.168.1.1/PartiesHallApp/api/';
  static const String baseUrlImage = 'https://192.168.1.1/PartiesHallApp/images/';
}