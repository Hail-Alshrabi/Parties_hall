const String txt_appName = 'قاعات الإحتفالات';
const String txt_notInternet = 'لايوجد إنترنت';

const String api_key_map ='AIzaSyDCYL2s8_yqIm0qVLxpx-pD58K83NHxkXA';